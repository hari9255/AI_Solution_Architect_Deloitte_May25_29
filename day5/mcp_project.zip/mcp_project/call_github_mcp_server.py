import asyncio
import os
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from langchain_mcp_adapters.tools import load_mcp_tools
from langchain_groq import ChatGroq
from langchain.agents import create_agent


async def run_github_agent():
    # 1. Define server parameters for the GitHub MCP server
    # Ensure you have GITHUB_TOKEN set in your environment variables
    server_params = StdioServerParameters(
        command="npx",
        args=["-y", "@modelcontextprotocol/server-github"],
        env={"GITHUB_TOKEN": "github_pat_11AIESVLY0xotkINj5jyFS_717WRurLqiFV0wgmZR6KW1gpdeVcYch1kPbaJsBDo67NPBJILDgnqROKw"}
    )

    # 2. Establish connection and load tools
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            # Initialize the MCP connection
            await session.initialize()
            
            # Load tools into LangChain format
            tools = await load_mcp_tools(session)

            # 3. Set up the LangChain Agent
            llm = ChatGroq(model="openai/gpt-oss-120b", temperature=0,api_key="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")
            agent = create_agent(llm, tools)
            system_prompt = '''
                    analyze user query and pick the appropriate tool related to github repository operations.''' 
            final_prompt=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": "list all repositories for the user 'hari9255"},       
                    ]  

            result= await agent.ainvoke({"messages": final_prompt})
            print("Agent's response:", result["messages"][-1].content)

if __name__ == "__main__":
    asyncio.run(run_github_agent())
