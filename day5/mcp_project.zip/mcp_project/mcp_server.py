from fastmcp import FastMCP
from langchain_tavily import TavilySearch

mcp = FastMCP("MCP_Server")

import os
os.environ["TAVILY_API_KEY"] = "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"

@mcp.tool
def web_search(query: str) -> str:
    """
    Perform a web search to extract latest or current information.
    """
    print("web search called with query:", query)
    search = TavilySearch(max_results=3)
    results = search.invoke(query)
    return str(results)

@mcp.tool
def add(a: int, b: int) -> int:
    """Add two numbers together."""
    print("add called with a:", a, "b:", b)
    return a + b

@mcp.tool
def multiply(a: int, b: int) -> int:
    """Multiply two numbers together."""
    print("multiply called with a:", a, "b:", b)
    return a * b

if __name__ == "__main__":
    mcp.run(transport="sse",port=8000)

    