import asyncio
import warnings
#ignore deprecation warnings 
warnings.filterwarnings("ignore", category=DeprecationWarning)
from langchain.agents import create_agent
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_groq import ChatGroq
from langchain.tools import tool
import sys

client = MultiServerMCPClient({
    "MCP_Server": {
        "transport": "sse",
        "url": "http://localhost:8000/sse",
    }
})

async def setup_tools():
    tools =await client.get_tools()
    return tools

async def main():
    llm = ChatGroq(model="openai/gpt-oss-120b", temperature=0,api_key="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")
    tools = await setup_tools()
    agent = create_agent(llm, tools)
    system_prompt = '''
                    You are a helpful assistant that can perform web searches and basic arithmetic operations.''' 
    final_prompt=[
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": "add 10 and 20"},
       
    ]  

    result= await agent.ainvoke({"messages": final_prompt})
    print("Agent's response:", result["messages"][-1].content)

if __name__ == "__main__":
    asyncio.run(main())